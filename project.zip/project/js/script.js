const setColor=document.getElementsByClassName("setColor");
const draw_me=document.getElementsByClassName("draw_me");
let color='white';
let colors=["white","blue","red","yellow","orange"]
for(let i=0;i<setColor.length;i++){
    setColor[i].style.backgroundColor=`${colors[i]}`;
    setColor[i].addEventListener('click',function(){
        for(let j=0;j<setColor.length;j++){
            if(setColor[j].classList.contains("active")){
                setColor[j].classList.remove("active");
            }
        }
        setColor[i].classList.add("active");
        color=colors[i];
    })
}
for(let i=0;i<draw_me.length;i++){
    draw_me[i].addEventListener('click',function(){
        draw_me[i].style.backgroundColor=color;        
    })
}
